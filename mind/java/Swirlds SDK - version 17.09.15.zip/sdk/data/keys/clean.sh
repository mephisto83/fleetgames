rm    *.pfx        2> /dev/null
rm    -r unused/*  2> /dev/null